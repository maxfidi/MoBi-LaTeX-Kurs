# Ordner für Strukturformeln
