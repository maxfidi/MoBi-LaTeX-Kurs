# Ordner für Bibliographie
Hier soll die `.bib` Datei die mit dem Literaturverwaltungsprogramm erstellt wird liegen.
Ebenfalls liegen hier die Zitierstile (Cell)

es empfiehlt sich, für Internetquellen die Klasse @MISC zu verwenden, für Kapitel in einem Buch @inproceedings

Beispiele:
@MISC{glideSPXP,
	AUTHOR = {{Schrödinger Inc.}},
	TITLE = {What are the main differences between HTVS, SP, and XP docking? In Schrödinger Knowledge Base},
	HOWPUBLISHED = {\url{https://www.schrodinger.com/kb/1013}},
	YEAR = {2015},
	series = {Schrödinger Knowledge Base},
	volume = {2021},
	number = {28.09.2021},
}
gibt:
Schrödinger Inc. (2015). What are the main differences between HTVS, SP, and XP
docking? In Schrödinger Knowledge Base. https://www.schrodinger.com/kb/1013.

@inproceedings{epilepsien,
	author = {Hamer, Hajo and Winkler, Frank},
	title = {Epilepsien},
	booktitle = {Neurologie, 14. edn},
	editor = {Hacke, Werner},
	publisher = {Springer},
	address = {Berlin, Heidelberg},
	edition = {14. edn},
	chapter = {},
	pages = {391-425},
	ISBN = {978-3-662-46891-3},
	DOI = {10.1007/978-3-662-46892-0},
	year = {2016},
	type = {Book Section}
}
gibt:
Hamer, H. and Winkler, F. (2016). Epilepsien. In Neurologie, 14. edn, W. Hacke,
ed. (Berlin, Heidelberg: Springer), pp. 391–425.
