# LaTeX_MoBi

Short introduction into LaTeX for MoBi Students in Heidelberg.
Repo provides a quick and dirty LaTeX in Overleaf tutorial and templates students may
through their studies.

----

LaTeX is not a program persey, it is a *markup* language similar to html, (R)markdown and so on.
Here we will provide you with programs/websites to use LaTeX and templates to get started.

You will also find tips and programs how to keep/organise a Bibliography for usage with LaTeX.


## I want my documents to wear LaTeX, but where do I start?

For the beginning we suggest to start on [Overleaf](https://www.overleaf.com/).
Overleaf allows for editing and compiling (ie. producing the pdf) in the browser.
As such you do not have to install LaTeX yourself, unless you feel adventures.
Then suggest: MiKTeX on Windos; MacTex for Mac; apt, pac & co. for linux.
A further benefit of Overleaf is, that it allows for collaborative editing similar to
google docs.
In the following we assume that you are working on Overleaf.
<img src="./tutorial_files/overleaf.jpg" width="50%" height="50%">


# Overleaf the basics

Start as follows:

1. Navigate to the folder of the template you want to use inside this repo
2. In your overleaf start page click new project and select upload project,
   drag/place the zip into the pop-up window.
3. You can now start working on the project.

Alternatively one can link gitlab/hub repos to overleaf, if you want to do this.

To compile a project with overleaf simply click compile in the upright corner.
To include new images in your project upload them and place them into the image folder of the project.


# LaTeX the basics.

__Let's start with a simple file:__ 

``` latex
\documentclass{article}

\begin{document}
    some text 
\end{document}
```

## The document class

+ first line of the document defines the class of the document in the curved brackets
+ the document class comes with a predefined format
+ this format can be adjusted later on

So beginning your document you can choose out of several layouts: 

+ report
+ article
+ book
+ letter
+ slides
+ beamer

...and others.
In order to see how changing the class influences our layout, you can take the document_class.tex file from the start_templates folder and put it into your overleaf. 
By changing the class in the curved brackets to one of the above classes, you can investigate how the layout changes. 

## commands, arguments, options and environments

Let's move on to the syntax of tex. 

``` latex
\documentclass{article}

\begin{document}
    some text 
\end{document}
```

__Commands__ are the tools with which you can format and edit your document. ´´documentclass´´ is such a command. 
Commands take as an input __arguments__ and __options__. 
The __arguments__ need to be written into the curved brackets and the __options__ are written into square brackets.
In our example file documentclass is the command. Article defines the class of the document and is thereby the given argument. 
Additionally, options can be specified, describing additional properties of the documents.
Like in the example below.

``` latex
\documentclass[12pt]{article}

\begin{document}
    some text 
\end{document}
```

__Environments.__ Till now, we defined the layout of our file by setting the document class and additional options. 
Now to actually write into our document, the document environment needs to be opened. 
All the content (text, tables, figures etc.) needs to be inserted in this document environment. 
The content inside this document environment, will be formated according to the layout we set in the lines above. 

+ So Environments are format blocks
+ in order to define other formats, like figures, tables, formulas etc. we need to open additional environments



``` latex
\documentclass[12pt]{article}

\begin{document}
    A forumla


    \begin{align}
        f(x) = x^2
    \end{align}


\end{document}
```


## text format

+ sections, paragraphs, italic, bold
+ list of contents


## references and Bibliography

+ how is it integrated into the file
+ simple example
+ \cite commad

## Figures and Tables

+ one simple and one complex example for both


## other 

+ importing a tex file
+ concept main.tex
+ how a structure your file folder



# Bibtex the basics.
Citing is easy, in LaTeX every citation is assigned a unique name (label) either
by you, your Citation manager or the publisher.
When citing simply use `\cite{theLabel}` and Bibtex (or overleaf) will place your citation here.

Everyone uses different Citation managers.
The easiest to use in combination to with LaTeX are either
those where you can export the bibliography as bib file or
those that use a bib file as database (such as BibDesk on mac and JabRef on Windows/Linux).

Either way whatever you use try to avoid editing of the bib files by hand,
this tends to introduce errors by missing brackets and such.
If you add a new citation to you bibliography watch out for special letters
such as ä,ö,ü,é.
In some cases the bib files are badly formatted by the publisher or by the program
you use for import of the citation.
If you keep this in mind, most errors in compiling resulting from the bib. are solvable
by simply googling the latex command for the letter and replacing.
