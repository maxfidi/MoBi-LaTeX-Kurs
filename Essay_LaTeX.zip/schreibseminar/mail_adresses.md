mobimaster19@listserv.uni-heidelberg.de
mobimaster20@stura.uni-heidelberg.de
mobimaster21@stura.uni-heidelberg.de 
mobimaster15@listserv.uni-heidelberg.de 
MOBIMASTER17@listserv.uni-heidelberg.de 
MOBI-MASTER-WS16@listserv.uni-heidelberg.de 
mobimaster18@listserv.uni-heidelberg.de
