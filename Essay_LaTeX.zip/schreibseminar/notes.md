# Schreibseminar 2022

## Zeitraum:
- Letzter Klausurtermin ist am 09. Maerz.2022
- Deadline paper selbst auswahl ab Maerz.
- 3. -- 4. Maerz Woche
- Abgabe: 12.04.2020
- Erster vortrag: Anfang Mai

## Letztes Jahr
- 8 Termine (das gleiche)
- Online

## Planung

- Aufteilung/Termine: sich meldende Studenten
- Vorrang: Master studierende rueckfallen auf 3tes Semester Studenten.
- Ein termin schreiben/HowToReadAPaper, zwei termine overleaf/latex/bibtex oder word/endnote/mendely
- Ende April praesention termin.



Schreiben/Lesen von Essay/Paper: 4 Termine

- 11.03
- 13.03
- 14.03
- 16.03

Schreibprogramme und Bibliography: 3 Termine

- 18.03 (2 Termine: LaTeX, Word)
- 19.03 (2 Termin: LaTeX, Word)

Praesentationen: 2 Termine

- 13.04
- 20.04



