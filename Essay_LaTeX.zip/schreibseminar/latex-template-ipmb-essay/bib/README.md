# Ordner für Bibliographie
Hier soll die `.bib` Datei die mit dem Literaturverwaltungsprogramm erstellt wird liegen.
Ebenfalls liegen hier die Zitierstile (Cell)
