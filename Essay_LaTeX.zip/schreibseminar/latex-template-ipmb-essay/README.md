# Vorlage für IPMB Essay
Autor: 		Nicolas Peschke

Die Vorlage kann unter Studenten der Molekularen Biotechnologie der	Universität Heidelberg weitergegeben und verwendet werden.

Für die Richtigkeit und Konformität des Layouts mit den Richtlinien des IPMBs wird keine Haftung übernommen, **BITTE SPRECHT AUF JEDEN FALL DAS LAYOUT EURER ARBEIT MIT EUREN BETREUERN AB!!!**

Um die Titelseite zu setzen müsst ihr nur in dieser Datei unter "Definitionen für Titelseite" die auf euch passenden Eintragungen vornehmen.
Für das Zitieren muss im Befehl `\addbibresource{bib/essay.bib}` durch den Dateinamen und Dateipfad eurer BibTeX Datei aus Citavi/Zotero/etc. an.
