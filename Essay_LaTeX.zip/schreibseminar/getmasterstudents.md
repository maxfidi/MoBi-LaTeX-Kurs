Liebe Master-MoBis,

Die Fachschaft organisiert ähnlich zu den Master4Bachelor
Seminaren dieses Jahr auch wieder Schreib-Seminare.

Wer so ein Schreib-Seminare hält, kann sich dieses als
3 Vortragszusammenfassungen anrechnen lassen.
Eintragen könnt ihr euch hier:
    https://heibox.uni-heidelberg.de/f/1595f4ceee7f4b509898/


Insgesamt sind 10 online Termine geplant, davon sind:
- vier "normale" Schreibseminare, wie sie auch in den Jahren
  zuvor stattgefunden haben. (hier gibt es bereits Folien)
- vier Software (Word+Endnote, LaTeX+BibTeX) Seminare.
  Für die Word/Endnote Seminare wäre es super,
  wenn jemand ein Tutorial/Folien erstellen könnte.
- Zwei Präsentations-Seminare. (Hier werden bereits Folien erstellt)

Wir würden uns über eure Teilnahme freuen,

Mit freundlichen Grüßen,

Anton Hanke & Anne-Clair Kröger
